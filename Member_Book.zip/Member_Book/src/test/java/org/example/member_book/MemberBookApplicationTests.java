package org.example.member_book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemberBookApplicationTests {

    @Test
    void contextLoads() {
    }

}
